Neighborhood Map

To run the application you should some steps first

1- download the Neighborhood Map project zip file
2- extract the file
3- open index.html and enjoy the Neighborhood Map
